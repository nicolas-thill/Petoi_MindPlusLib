model_ = ''
useMindPlus = True
